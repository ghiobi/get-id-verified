<a class="giv_image_preview" href="<?= $url ?>" target="_new">
    <img style="max-width: 100%" src="<?= $url ?>">
</a>