<?php if(!Get_Id_Verified_User::image()): ?>
  <div id="giv_checkout">
    <h3>
      <?= __('Upload Government Id', GIV_PLUGIN_NAME) ?>
    </h3>

    <?php include 'image_uploader.php'; ?>
  </div>
<?php endif; ?>